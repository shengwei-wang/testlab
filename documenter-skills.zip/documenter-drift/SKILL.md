---
name: documenter-drift
description: Keep generated technical and business docs in sync with source after code changes, by re-deriving ONLY the docs affected by a merge diff — never re-generating unchanged docs. Use this skill whenever the user says docs are stale after a PR/merge, asks to "update the docs for these changes", "refresh docs after PR #N", "check which docs the diff affects", or wires doc-drift checking into CI (GitHub Actions). Trigger even on casual phrasings like "the docs are out of date now" or "did my change break any docs". This is the REUSED, CI-driven path — it is isolated from the generator skills so it loads minimal context and can be versioned independently. Do NOT use it for first-time documentation of a module (use documenter) or business capability (use documenter-business).
---

# Documenter — Drift

Given a merge diff (or a list of changed files), update only the docs those changes affect, and
leave everything else untouched. This is the path that runs repeatedly in CI, so it is
deliberately lean: it does not carry module/architecture/business prose in context — it maps
changed files to affected docs, then delegates the actual re-derivation.

## Before anything: load the grounding core
Read `.claude/skills/_shared/grounding-core.md` (or `references/grounding-core.md` if installed
standalone) and apply the iron rules, four-step procedure, frontmatter contract, and validator
contract. This skill changes *which* docs get regenerated, not *how* a doc is grounded.

## Step 1 — Map changed source files → affected docs (the part the original skill hand-waved)

Do this deterministically, not by guessing. In priority order:

1. **Reverse citation index (primary).** Read `docs/.citation-index.json` — emitted by the
   validator (grounding core §5). It maps each cited source path → the docs that cite it.
   For each changed file in the diff, look it up to get the exact set of affected docs in O(1).
   This catches **business docs that cite a changed module's doc**, which a naive grep over
   source paths would miss.
2. **Build-module fallback.** For a changed file with no index entry (e.g. a brand-new file),
   resolve its **owning build module** (the `artifactId` / Gradle project path of the nearest
   enclosing `pom.xml` / `build.gradle`) and flag `docs/technical/modules/<module>.md` plus any
   doc the index shows citing that module doc.
3. **Grep fallback (last resort).** If `docs/.citation-index.json` is missing or stale, grep
   every doc under `docs/` for the changed path. **Warn the user this is slower and may
   under-catch** (it won't follow doc→doc citation chains the way the index does), and
   recommend running a full generate pass to rebuild the index.

Produce an explicit **affected-docs list** before touching anything, and show it to the user /
log it in the PR. If the diff touches a module with no doc at all, surface that as a coverage
gap (`UNDOCUMENTED MODULE — run documenter`), don't silently skip it.

## Step 2 — Re-derive only the affected docs

For each affected doc, re-run the appropriate generator's four-step procedure on **only** that
doc — technical module docs via the `documenter` module-mode procedure, business docs via the
`documenter-business` procedure. **Never re-derive unchanged docs**; that wastes inference and
risks churn in audited artifacts. Architecture docs are aggregations — only refresh an
architecture doc if one of its underlying module docs actually changed in this pass.

## Step 3 — Patch in place and re-stamp

- Patch only the affected sections of each doc.
- Bump `generated_at` and `source_commit` to the merge commit.
- **Reset `verified_by: pending`** — a regenerated section is unverified again until a human
  re-signs. Do not preserve a prior human signature across a content change; that would forge
  verification.
- Recompute `audit_grade` from the rule in the grounding core (§4) for the surface this drift
  run executed on. If drift runs in CI under the Copilot agent without an enforced read-only
  wrapper or executable validator, the patched docs are `audit_grade: false` — make CI fail
  loudly rather than emit audit-grade-looking docs that aren't.

## Step 4 — Validate and summarize for the PR

- Run the **blocking validator** on every patched doc; a non-zero exit fails the drift run.
  The validator also refreshes `docs/.citation-index.json` so the next drift run stays fast.
- Emit a one-line-per-doc summary for the PR description: which doc, which sections changed,
  validator result, audit grade.

## CI wiring note (GitHub Actions)
Run this on PRs touching source. Recommended gate: fail the check if (a) any affected doc fails
the validator, or (b) a changed module has no doc (coverage gap), or (c) docs were patched but
land `audit_grade: false` on a branch that requires audit-grade docs. Keep the job read-only on
source; it writes only under `docs/`. Mind the ETH Zurich cost finding — drift runs add
inference cost per PR, so scope the trigger to source paths, not every PR.

## Reference & asset files
- `references/grounding-core.md` — copy of the shared core (only if installed standalone).
- `scripts/validate_citations.py` — the blocking validator; also (re)builds the reverse index.

## Compliance note
Drift patches reset `verified_by: pending` and recompute `audit_grade` honestly. This SKILL.md
and the shared core are change-controlled E-23 artifacts — version them, do not edit silently.
