---
name: documenter-business
description: Generate citation-grounded BUSINESS-FACING capability documentation for Front Office and Operations audiences from the human-maintained glossary plus existing technical module docs, WITHOUT hallucination and WITHOUT code jargon. Use this skill whenever the user asks to "explain capability X for the business", "write a plain-language summary of what this does", "tell the business side what happens if this fails", "document this for Ops/Front Office", or references files under docs/business/. Trigger even on casual phrasings — "what does this mean for the desk", "write the non-technical version". This is the highest-redaction, highest-external-claim-risk mode: it is isolated from the technical skill on purpose. Do NOT use it to read source directly (it reads module docs, never code) and do NOT use it for technical/architecture docs (use documenter) or drift updates (use documenter-drift).
---

# Documenter — Business

Translate already-verified technical module docs into plain-language capability summaries for
Front Office and Operations. This mode carries the **highest risk in the suite**: the audience
can't sanity-check against code, the claims may reach external/regulatory readers, and the
redaction surface is largest. That is exactly why it is a separate skill with its own review
cycle — keep it that way.

## Before anything: load the grounding core
Read `.claude/skills/_shared/grounding-core.md` (or `references/grounding-core.md` if installed
standalone) and apply it in full. The iron rules, four-step procedure, frontmatter contract,
validator contract, and redaction rule all apply here unchanged.

## Two hard preconditions (stop if either is missing)
1. **`docs/glossary.md` must exist.** It is the human-maintained business vocabulary. Business
   intent cannot be reliably inferred from code — if the glossary is missing, **stop and ask
   the user to create it.** Do not proceed by guessing what a capability "means" to the desk.
2. **Technical module docs must exist** for the modules involved. This skill reads
   `docs/technical/modules/*.md`, **never source.** If the relevant module doc is missing,
   say so and offer to run `documenter` (module mode) first.

## Procedure

For each capability named in the glossary:

1. **Find the implementing module(s).** Match the glossary capability to the module doc(s)
   that implement it. Cite the module-doc filename + section. If no module doc implements it,
   write `NOT FOUND IN CODEBASE — confirm with SME` — this is a success, not a gap to paper over.
2. **Write a ~200-word plain-language summary.** No code identifiers, no class/method/queue
   names, no engineering jargon. Describe what the capability does in the desk's / Ops' terms,
   grounded entirely in the cited module docs and glossary.
3. **State operational impact if it fails.** Drive this from the module doc's
   data-flow/side-effects section (e.g. "if this fails, settlement instructions are not sent")
   — cite the module-doc section. Do not invent severities, SLAs, or downstream consequences
   the technical docs don't support; those are `UNKNOWN — needs SME confirmation`.
4. **No business rules not stated in code or glossary.** If the desk's actual rule isn't in the
   glossary and isn't visible in the cited module doc, it is UNKNOWN. This is the single most
   common place business docs hallucinate — hold the line.

Use `assets/business-template.md` as the skeleton.

## Redaction is at its most important here
Front-Office-facing docs are the likeliest to leak counterparty IDs, account numbers, trader
names, or P&L into a widely-read document. Apply the redaction rule (grounding core §1.5)
strictly, and remember it is best-effort vigilance, not an enforced control — flag anything
that looks sensitive rather than transcribing it.

## Validate and stamp
Run Step 3 (self-check → **blocking validator**) and Step 4 (frontmatter). Citations here point
to module-doc line ranges; the validator checks those just as it checks source citations. A
business doc that skipped the validator must be stamped `audit_grade: false`,
`validator: not-run`, and called out as a draft — never as something a regulator can rely on.

## Reference & asset files
- `references/grounding-core.md` — copy of the shared core (only if installed standalone).
- `assets/business-template.md` — business-doc skeleton.
- `references/capital-markets-glossary-starter.md` — seed vocabulary to adapt into
  `docs/glossary.md`; adapt, don't adopt blindly.
- `scripts/validate_citations.py` — the blocking citation validator.

## Compliance note
Business docs are human-review-gated and default to `audit_grade: false`. `verified_by` stays
`pending` until a capability owner (business SME, not an engineer) signs off. This SKILL.md and
the shared core are change-controlled E-23 artifacts — version them, do not edit silently.
