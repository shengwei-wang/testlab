---
name: documenter
description: Generate citation-grounded TECHNICAL documentation (module-level and architecture-level) from Java source in a legacy monorepo, WITHOUT hallucination. Use this skill whenever the user asks to document a Java module, summarize what a class/package/service does, produce or update architecture docs, map dependencies and call graphs, or describe data flow and side effects (DB, JMS/MQ, Solace, HTTP). Trigger even on casual phrasings like "document this module", "what does this service do", "write up the architecture", "explain how this package fits together", or any reference to files under docs/technical/. Always prefer this skill over ad-hoc summarization — it enforces line-level citations, an UNKNOWN escape hatch, a blocking citation validator, and honest audit-grade stamping that plain summarization does not. Do NOT use this for business-facing capability docs (use documenter-business) or for updating stale docs after a merge (use documenter-drift).
---

# Documenter — Technical (module + architecture)

Produce technical docs an auditor can verify line-by-line. Two modes live here because they
are chained: architecture mode consumes the module docs this same skill produces, and you
will almost always regenerate architecture right after a module sweep.

## Before anything: load the grounding core
Read `.claude/skills/_shared/grounding-core.md` (or `references/grounding-core.md` if this
skill was installed standalone) and apply it in full: surface awareness (§0), iron rules
(§1), the four-step procedure (§2), the Serena/efficiency rule (§3), the frontmatter contract
(§4), the validator contract (§5), and the Java evidence playbook (§6). This SKILL.md only
adds the two technical modes on top of that core.

## Mode selection

| User intent | Mode | Output |
|---|---|---|
| "Document module X" / full sweep of a build module | **Module mode** | `docs/technical/modules/<module>.md` |
| "Write up the architecture" / "how do these fit together" | **Architecture mode** | `docs/technical/architecture/*.md` |

If the request is ambiguous, ask which — module mode reads source; architecture mode must not.

---

## Module mode

Run the four-step procedure from the grounding core, gathering Java evidence per §6. Produce,
in this order, each item cited to a quote ID (use `assets/module-template.md` as the skeleton):

1. **Purpose** — 1–2 sentences, cited to the primary type's declaration/Javadoc.
2. **Public surface** — public types and methods, each signature cited.
3. **Dependencies** — build-level (`pom.xml`/`build.gradle` coordinates) and code-level
   (injected fields, first-party imports), each cited.
4. **Downstream callers** — `find_referencing_symbols` (or grep fallback), each call site
   cited; note reflective/Spring-wired usage as a possible blind spot.
5. **Data flow & side effects** — inputs, outputs, and every external touch (DB / JMS·MQ /
   Solace / HTTP / scheduler / config), each cited; redact values and counterparty-bearing
   names. This is the section auditors care about most — be exhaustive and exact.
6. **UNKNOWNS** — everything the source can't establish (business rationale, SLAs, ownership,
   concurrency intent behind `synchronized`/thread pools). Mark, never infer.

**Refusal guard:** if Serena symbols don't resolve for this module and it exceeds ~2k LOC,
stop and tell the user to load Serena (and ensure the module's classpath resolves) before
proceeding — do not silently fall back to whole-file reads on a large module (grounding core §3).

Finish with Step 3 (self-check → **blocking validator**) and Step 4 (frontmatter). A module
doc that failed or skipped the validator is not done — say so honestly.

---

## Architecture mode

**Read ONLY `docs/technical/modules/*.md` — never re-read source here.** Architecture mode is
an aggregation pass; re-reading source reintroduces hallucination risk the module docs already
controlled for. If a module doc you need is missing, say so and offer to run module mode first
rather than inventing the gap.

Aggregate the module docs into:
- `overview.md` — what the system is and its major moving parts.
- `components.md` — each component = a module doc; one cited paragraph each.
- `data-flow.md` — how data moves between modules, built only from the module docs'
  data-flow/side-effects sections.
- `deployment.md` — only what module docs actually state (build modules, queues, schedulers,
  external endpoints); everything else is UNKNOWN.

Rules specific to this mode:
- **Cite by module-doc filename + section**, not by source path (you didn't read source).
- **Mermaid diagrams may use only names that appear in the module docs.** No invented edges or
  nodes. An edge must trace to a module doc's downstream-callers or data-flow section.
- **Contradiction between module docs → `TODO(reviewer)`**, not silent resolution. Two module
  docs disagreeing is signal, not noise.
- Stamp frontmatter per the contract; `source_commit` is the commit the underlying module docs
  were verified against (carry it forward; if module docs disagree on commit, that's a
  `TODO(reviewer)`).

---

## Reference & asset files
- `references/grounding-core.md` — copy of the shared core (only if installed standalone;
  otherwise use `.claude/skills/_shared/grounding-core.md`).
- `assets/module-template.md` — module-doc skeleton.
- `scripts/validate_citations.py` — the blocking citation validator (grounding core §5).

## Compliance note
Generated docs are human-review-gated: `verified_by` stays `pending` until a module owner
signs off, and `audit_grade` is `false` unless read-only was enforced and the validator
passed. Treat this SKILL.md and the shared core as change-controlled E-23 artifacts — version
them, do not edit silently.
