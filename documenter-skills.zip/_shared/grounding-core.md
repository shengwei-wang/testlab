# Grounding Core (shared by documenter, documenter-business, documenter-drift)

This is the single source of truth for the grounding rules, the four-step procedure,
the frontmatter contract, and the citation validator contract. The three `documenter-*`
skills are thin wrappers that add mode-specific behaviour on top of this file.

**Treat this file as a change-controlled evidentiary artifact under OSFI E-23.**
Version it, PR-review it, never edit it silently. A change here alters the audit
guarantees of every doc the suite produces, so re-validate all three skills after any edit.

**Where this file lives.** Canonical path: `.claude/skills/_shared/grounding-core.md`
(shared across Claude Code and the Claude agent in GitHub Copilot via the shared
`~/.claude`). If a skill is installed standalone where that path is unavailable, copy
this file into that skill's `references/grounding-core.md` and point to the copy.

---

## 0. Surface awareness (read this first — it decides whether output is audit-grade)

The same skill runs on two surfaces with **unequal enforcement guarantees**. Detect which
surface you are on and stamp it honestly; do not let the two produce identical-looking
frontmatter when their guarantees differ.

| Surface | Read-only enforcement | Validator can execute? | Default audit grade |
|---|---|---|---|
| **Claude Code** | Run inside the read-only subagent wrapper — writes outside `docs/` are physically blocked | Yes (`bash`) | **audit-grade** when validator passes |
| **Copilot Claude agent (VS Code)** | Advisory only — you are *told* not to write outside `docs/`, nothing enforces it | Only if shell/terminal execution is enabled in this session | **non-audit-grade** unless the validator demonstrably ran |

Rules that follow from this:

1. On **Copilot**, before writing anything, confirm you can run the validator in this
   session. If you cannot, you may still produce a draft, but it is **non-audit-grade** and
   the frontmatter must say so (`audit_grade: false`, `validator: not-run`,
   `verified_by: validator-not-run`). Tell the user plainly: "This was generated on the
   Copilot surface without enforced read-only or an executed validator — treat it as a
   draft, not as E-23 evidence."
2. Never write `audit_grade: true` unless **both** read-only was enforced **and** the
   validator exited 0 in this session. `audit_grade` is derived, not asserted — see §4.
3. Under Claude Code, stay inside the read-only subagent wrapper for evidence gathering and
   only break out of read-only to write into `docs/`. Under Copilot, write **only** into
   `docs/` and touch nothing else.

---

## 1. Iron rules (non-negotiable, all modes)

1. **Never invent.** Class/interface/method/package names, Maven/Gradle coordinates,
   Spring beans, config keys, queue names, table names, business terms — if it is not in
   the source, it does not go in the doc.
2. **Cite everything.** Every factual sentence ends with a quote ID and a citation
   `[path:line-range]`. No citation, no claim.
3. **UNKNOWN over guessing.** If the source does not state it, write
   `UNKNOWN — needs SME confirmation` and move on. Recording an UNKNOWN is a success, not a
   failure. Hallucinated certainty is the only real failure.
4. **Read-only on source.** Never edit source. Write only into `docs/`. Enforcement
   strength is surface-dependent (§0) — when it is only advisory, compensate with extra care
   and an honest stamp.
5. **Redact confidential data.** Never copy secrets, API keys, account/counterparty IDs,
   trader names, or P&L figures into docs even if they appear in code, comments, or
   `application*.properties`. Redaction here is best-effort model vigilance, **not** a
   control — never represent it as one. If you encounter what looks like a live secret in
   source, note `REDACTED — possible secret at [path:line]` and flag it to the user.

---

## 2. The four-step procedure (every mode runs this)

### Step 1 — Gather evidence first (verbatim quotes before any prose)

Collect quotes before writing a single sentence of doc. Prefer Serena MCP symbolic tools
over reading whole files — it keeps token use down and citations tight. See §6 for the
Java-specific evidence playbook (JDT symbols, Maven/Gradle, Spring/JMS/JPA side effects).

Emit a `<quotes>` block with stable IDs:

```
<quotes>
[Q1] oms/router/SmartRouter.java:120-138  "public Order route(Order o) { ... }"
[Q2] oms/router/SmartRouter.java:45        "private final PreTradeRiskCheck preTrade;"
[Q3] oms/router/pom.xml:31-34              "<artifactId>mq-jms-spring-boot-starter</artifactId>"
</quotes>
```

If you cannot find a quote to support a point you intended to make, **you do not make that
point** — it goes under UNKNOWNS. This is the core anti-hallucination move.

### Step 2 — Write the doc, each claim tagged to a quote

Every asserting sentence ends with its quote ID and citation:
"The router runs a pre-trade risk check before submission [Q2] (oms/router/SmartRouter.java:45)."

### Step 3 — Self-check, then the validator (the validator is the real gate)

First emit a `<self-check>` block listing every claim and its supporting quote ID. This is a
**drafting aid only** — a model grading its own output catches little. Its value is forcing
you to notice an unsupported claim before you ship it, not certifying correctness.

The **authoritative gate is the validator**. Run it and block on a non-zero exit:

```bash
python scripts/validate_citations.py <doc-path> --repo-root <repo> --source-commit <sha>
```

- Exit 0 → stamp `validator: passed`.
- Non-zero → a citation is fabricated, stale, or text-mismatched. **Fix and re-run. Do not
  return the doc.** A doc that failed the validator is INVALID and must not be presented as
  finished.
- **Validator could not run** (Copilot without shell, or script missing) → stamp
  `validator: not-run`, `audit_grade: false`, `verified_by: validator-not-run`, and say so
  explicitly. Never let an unvalidated doc carry frontmatter that implies verification.

### Step 4 — Stamp audit frontmatter (see §4 for the exact contract)

Prepend the frontmatter block. Compute `audit_grade` from the rule in §4 — never hand-assert it.

---

## 3. Evidence-token budget and Serena dependency (efficiency rule)

Serena is **load-bearing for cost and citation tightness**, not optional polish. State its
status explicitly at the top of every run:

- **Serena available** (symbol tools resolve): use `find_symbol` /
  `find_referencing_symbols` / `get_symbols_overview`. Read whole files only to confirm a
  specific quoted range.
- **Serena unavailable** (not loaded, or Java LSP can't resolve symbols — see §6): you fall
  back to whole-file reads, which inflates tokens and loosens citations. In this state:
  - **Refuse full module/architecture mode on any module > ~2k LOC** rather than degrade
    silently — tell the user Serena must be loaded first.
  - For small modules only, you may proceed with whole-file reads but stamp
    `evidence_method: file-read-fallback` and treat the result as lower-confidence.

Do not pretend Serena ran when it didn't. The ETH Zurich AGENTS.md finding applies: context
files buy a small quality gain at real inference-cost and step-count overhead — so spend
tokens where they convert to verifiable citations, not on re-reading files Serena could index.

---

## 4. Frontmatter contract (exact)

```yaml
---
generated_by: <model-id>            # e.g. claude-opus-4-6 / claude-sonnet-4-6
generated_at: <ISO-8601>
source_commit: <git rev-parse HEAD> # the commit the citations were verified against
source_surface: claude-code | copilot-claude-agent
read_only_enforcement: subagent-readonly | advisory
evidence_method: serena | file-read-fallback
validator: passed | failed | not-run
audit_grade: <derived — see rule below>
verified_by: pending | <human-id> | validator-not-run
citation_count: <n>
unknowns_count: <n>
---
```

**`audit_grade` is derived, never asserted:**

```
audit_grade = true  IFF  read_only_enforcement == subagent-readonly
                    AND  validator == passed
              else false
```

So Copilot output is `audit_grade: false` by construction unless a future enforced-write
mechanism exists there. `verified_by` stays `pending` until a module owner signs off; a
human signature is what turns a passed-validator doc into accepted E-23 evidence. The model
never sets `verified_by` to a human name.

---

## 5. Validator contract (what `validate_citations.py` must guarantee)

The script is referenced, not shipped here. Implement it to this contract so the gate is
trustworthy:

1. **Pin to the commit, not the working tree.** Resolve every cited `[path:line-range]`
   against the blob at `--source-commit` (e.g. `git show <sha>:<path>`), **not** the current
   checkout. This prevents false failures (and, worse, silent false passes) when source has
   moved since generation.
2. **Exact text match.** The quoted snippet must match the cited line range verbatim
   (whitespace-normalised). A near-miss is a failure — that is how you catch a citation that
   drifted onto the wrong line.
3. **Existence + range sanity.** Cited line numbers must exist in the file at that commit.
4. **Emit the reverse citation index.** On success, write/update
   `docs/.citation-index.json` mapping each cited source path → the set of docs that cite it:
   ```json
   { "oms/router/SmartRouter.java": ["docs/technical/modules/oms-router.md"] }
   ```
   This index is what makes Drift mode fast and complete (see documenter-drift).
5. **Exit codes:** `0` all citations valid; non-zero otherwise, printing each offending
   citation with the reason (missing path / out-of-range / text-mismatch).

If the index cannot be written (read-only docs dir, etc.), the validator still gates on
citations but warns that drift mapping will fall back to grep.

---

## 6. Java / legacy-monorepo evidence playbook

This suite targets a legacy Java monorepo (Maven and/or Gradle multi-module). Use these
patterns in Step 1.

### 6.1 Serena on Java — and when it silently degrades
Serena's Java symbol resolution runs on the Eclipse JDT language server, which needs the
**module's classpath to resolve**. In a legacy monorepo a single module often won't build in
isolation, and JDT then returns empty or partial symbols. Guard against this:

- Scope Serena to the module's reactor (the module + the parent `pom.xml` / settings.gradle
  that defines its dependencies).
- If `find_symbol` returns empty for a class you can see exists in the file, treat symbol
  resolution as **failed** → apply the Serena-unavailable rules in §3. Do not paper over it
  by switching to whole-file reads without stamping `file-read-fallback`.

### 6.2 What to quote, per module-doc section

- **Purpose:** the primary public type's Javadoc/class declaration. Cite the declaration
  line, not your paraphrase.
- **Public surface:** `public` classes/interfaces/enums/records and their public methods.
  Use Serena `get_symbols_overview` / `find_symbol`; cite each signature.
- **Dependencies:**
  - *Build-level:* `<dependency>` entries in `pom.xml` or `dependencies {}` in
    `build.gradle(.kts)`. Cite the coordinate lines.
  - *Code-level:* constructor-injected / `@Autowired` fields, `import` statements for
    first-party modules. Cite them.
- **Downstream callers:** Serena `find_referencing_symbols` on the module's public types
  (cite each call site). If Serena is down, `grep -rn "ClassName"` across sibling modules and
  cite hits — but note in UNKNOWNS that grep may miss reflective/Spring-wired usage.
- **Data flow & side effects (the high-value, audit-relevant section):** identify and cite
  each external touch:
  - **DB:** JDBC `DataSource`, `@Transactional`, JPA `@Entity`/`@Repository`/`EntityManager`,
    MyBatis `@Mapper` / XML mappers, raw SQL strings. Cite the annotation or call.
  - **Messaging:** IBM MQ / JMS (`@JmsListener`, `JmsTemplate`, `MessageProducer/Consumer`,
    `MQQueue`), Solace (`JCSMPSession`, `XMLMessageProducer`). Cite the listener/producer and,
    where present, the configured queue/topic name (redact if it encodes a counterparty).
  - **HTTP/API in & out:** `@RestController`/`@RequestMapping`/JAX-RS for inbound; Feign,
    `RestTemplate`, `WebClient` for outbound. Cite the mapping or client call.
  - **Scheduling:** `@Scheduled`, Quartz `Job`. Cite the trigger.
  - **Config keys:** `@Value("${...}")`, `@ConfigurationProperties`, keys read from
    `application*.yml/properties`. Cite the key reference; **redact the value**.
- **UNKNOWNS:** anything the bytecode/source cannot tell you — business rationale, SLAs,
  upstream/downstream system ownership, why a queue exists. Mark, don't guess.

### 6.3 Legacy-Java traps to record as UNKNOWN rather than infer
God classes and static utility singletons hide control flow; `synchronized`/thread-pool code
hides concurrency intent; reflection and Spring XML wiring hide call graphs from both Serena
and grep. When behaviour depends on any of these and the source doesn't state intent, write
`UNKNOWN — needs SME confirmation`, naming the construct and citing where you saw it.

---

## 7. Module → doc → repo path conventions (shared across modes)

| Artifact | Path |
|---|---|
| Module doc | `docs/technical/modules/<maven-or-gradle-module>.md` |
| Architecture docs | `docs/technical/architecture/{overview,components,data-flow,deployment}.md` |
| Business capability doc | `docs/business/<capability>.md` |
| Business glossary (human-maintained) | `docs/glossary.md` |
| Reverse citation index (validator-emitted) | `docs/.citation-index.json` |

Name a module doc after its build-module identifier (the `artifactId` or Gradle project
path), not an invented label, so drift mapping from a changed file's owning module is
unambiguous.
